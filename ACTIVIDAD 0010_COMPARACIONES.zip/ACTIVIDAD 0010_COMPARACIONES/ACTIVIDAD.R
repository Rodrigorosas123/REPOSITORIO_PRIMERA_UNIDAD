# Instalar paquetes si no están
if (!require(dqrng)) install.packages("dqrng")
if (!require(ggplot2)) install.packages("ggplot2")
if (!require(dplyr)) install.packages("dplyr")
if (!require(gridExtra)) install.packages("gridExtra")

library(dqrng)
library(ggplot2)
library(dplyr)
library(gridExtra)

# Semilla para reproducibilidad
set.seed(123)

# Cantidad de datos
n <- 10000

# 1. LCG (runif base R)
lcg <- runif(n)

# 2. MT19937 (default de dqrng)
dqRNGkind("default")
mt <- dqrunif(n)

# 3. WELL (simulado con Xoshiro256++)
dqRNGkind("Xoshiro256++")
well <- dqrunif(n)

# 4. PCG64
dqRNGkind("pcg64")
pcg <- dqrunif(n)

# 5. xorshift128+ (aproximado con Xoroshiro128+)
dqRNGkind("Xoroshiro128+")
xorshift <- dqrunif(n)

# 6. ChaCha20 (si está disponible en tu versión de R)
if ("ChaCha20" %in% RNGkind()) {
  RNGkind("default", "default", "ChaCha20")
  chacha <- runif(n)
} else {
  chacha <- rep(NA, n)
  warning("ChaCha20 no está disponible en esta versión de R.")
}

# Unificar todos los vectores en un data frame
df <- data.frame(
  value = c(lcg, mt, well, pcg, xorshift, chacha),
  generator = rep(c("LCG", "MT19937", "WELL", "PCG", "xorshift128+", "ChaCha20"), each = n)
)

# Estadísticas descriptivas
stats <- df %>%
  group_by(generator) %>%
  summarise(
    min = min(value, na.rm = TRUE),
    max = max(value, na.rm = TRUE),
    mean = mean(value, na.rm = TRUE),
    sd = sd(value, na.rm = TRUE),
    var = var(value, na.rm = TRUE),
    cv = sd / mean
  )

print(stats)

# --------------- GRÁFICOS ----------------

# Histograma por generador
p1 <- ggplot(df, aes(x = value, fill = generator)) +
  geom_histogram(bins = 50, alpha = 0.6, position = "identity") +
  facet_wrap(~generator, scales = "free_y") +
  theme_minimal() +
  labs(title = "Distribución de 10,000 números por generador", x = "Valor", y = "Frecuencia")

# Boxplot comparativo
p2 <- ggplot(df, aes(x = generator, y = value, fill = generator)) +
  geom_boxplot(alpha = 0.7) +
  theme_minimal() +
  labs(title = "Boxplot por generador", x = "Generador", y = "Valor")

# Mostrar los gráficos juntos
grid.arrange(p1, p2, nrow = 2)
